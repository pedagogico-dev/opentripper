#!/usr/bin/env python3
"""Aplica a aba "Mapa" no repositorio OpenTripper.
Uso: python3 apply_patch.py /caminho/do/repo/opentripper
Depois confira com `git diff` e compile com ./gradlew assembleDebug
"""
import pathlib, re, shutil, sys

root = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
here = pathlib.Path(__file__).resolve().parent
main = root / "app/src/main"
if not (main / "AndroidManifest.xml").exists():
    sys.exit(f"Nao achei {main}/AndroidManifest.xml - passe a pasta raiz do repositorio.")

manual = []

# 1) copiar arquivos novos
java_dir = next((p.parent for p in (main / "java").rglob("MainActivity.java")), None)
if java_dir is None:
    sys.exit("MainActivity.java nao encontrada.")
(main / "assets").mkdir(exist_ok=True)
shutil.copy(here / "files/assets/map.html", main / "assets/map.html")
shutil.copy(here / "files/java/MapActivity.java", java_dir / "MapActivity.java")
print("OK  copiados MapActivity.java e assets/map.html")

# 2) manifest
mf = main / "AndroidManifest.xml"
t = mf.read_text(encoding="utf-8")
if "android.permission.INTERNET" not in t:
    t = re.sub(r"([ \t]*)<application",
               lambda m: f'{m.group(1)}<uses-permission android:name="android.permission.INTERNET" />\n\n{m.group(1)}<application',
               t, count=1)
    print("OK  permissao INTERNET adicionada")
if ".MapActivity" not in t:
    t = re.sub(r"([ \t]*)</application>",
               lambda m: f'{m.group(1)}    <activity android:name=".MapActivity" android:exported="false"\n'
                         f'{m.group(1)}        android:configChanges="orientation|screenSize|keyboardHidden" />\n{m.group(1)}</application>',
               t, count=1)
    print("OK  MapActivity declarada no manifest")
mf.write_text(t, encoding="utf-8")

# 3) botao na barra de abas
lay = main / "res/layout/activity_main.xml"
BTN = '''<Button
        android:id="@+id/btnTabMap"
        android:layout_width="0dp"
        android:layout_height="match_parent"
        android:layout_weight="1"
        android:text="&#128506;&#10;Mapa"
        android:textSize="11sp"
        android:textColor="#8B9BB4"
        style="?android:attr/borderlessButtonStyle" />'''
lt = lay.read_text(encoding="utf-8")
if "btnTabMap" in lt:
    print("--  botao ja existe no layout")
else:
    i = lt.find("@+id/btnTabDevice")
    done = False
    if i != -1:
        start = lt.rfind("<Button", 0, i)
        end = lt.find(">", i)
        if start != -1 and end != -1:
            if lt[end - 1] != "/":
                close = lt.find("</Button>", end)
                end = close + len("</Button>") - 1 if close != -1 else -1
            if end != -1:
                indent = re.search(r"[ \t]*$", lt[:start]).group(0)
                lt = lt[:end + 1] + "\n\n" + indent + BTN + lt[end + 1:]
                lay.write_text(lt, encoding="utf-8")
                done = True
                print("OK  botao Mapa adicionado a barra inferior")
    if not done:
        manual.append("Cole este botao dentro da barra de abas de res/layout/activity_main.xml:\n" + BTN)

# 4) clique do botao
ma = java_dir / "MainActivity.java"
mt = ma.read_text(encoding="utf-8")
if "btnTabMap" in mt:
    print("--  clique ja existe na MainActivity")
else:
    m = re.search(r"setContentView\s*\(\s*R\.layout\.activity_main\s*\)\s*;", mt)
    SNIP = ('\n\n        // OpenTripper: aba Mapa\n'
            '        android.view.View mapTab = findViewById(R.id.btnTabMap);\n'
            '        if (mapTab != null) mapTab.setOnClickListener(v ->\n'
            '                startActivity(new android.content.Intent(MainActivity.this, MapActivity.class)));')
    if m:
        mt = mt[:m.end()] + SNIP + mt[m.end():]
        ma.write_text(mt, encoding="utf-8")
        print("OK  clique ligado na MainActivity")
    else:
        manual.append("Em MainActivity.onCreate, apos setContentView(...), adicione:" + SNIP)

if manual:
    print("\n=== FALTOU FAZER A MAO ===")
    print("\n\n".join(manual))
print("\nPronto. Rode: git diff && ./gradlew assembleDebug")
