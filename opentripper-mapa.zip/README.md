# OpenTripper – aba "Mapa"

Adiciona uma tela de mapa no celular (OpenStreetMap): posição, rumo, rastro, velocidade, zoom automático por velocidade, botão de recentralizar e alternância mapa escuro/claro.

## Como aplicar
1. `git clone https://github.com/OSolerHugo/opentripper && cd opentripper`
2. `python3 /caminho/para/apply_patch.py .`
3. `git diff` para conferir e `./gradlew assembleDebug` (ou envie ao GitHub Actions do repositório).
4. APK em `app/build/outputs/apk/debug/`.

O script é idempotente. Se não achar algum trecho, imprime o que colar manualmente.

## O que muda
- Novos: `MapActivity.java`, `assets/map.html`
- `AndroidManifest.xml`: permissão INTERNET + declaração da MapActivity
- `activity_main.xml`: botão "Mapa" na barra inferior
- `MainActivity.java`: 3 linhas ligando o botão

## Limitações
- Precisa de internet (tiles via CARTO/OSM; o cache do WebView ajuda um pouco).
- Não desenha a rota do Google Maps/Waze: as notificações só trazem a próxima manobra, sem geometria. Mostra seu rastro.
- O Pod continua recebendo só ícones; o mapa aparece apenas no celular.
- Fonte de tiles trocável em `map.html` (objeto `layers`). Uso intenso: use provedor próprio (MapTiler, Stadia etc.).
